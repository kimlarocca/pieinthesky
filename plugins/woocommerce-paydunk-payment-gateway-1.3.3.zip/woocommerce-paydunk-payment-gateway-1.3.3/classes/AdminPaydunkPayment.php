<?php
if (!defined('ABSPATH'))
    exit;

if (!class_exists('AdminPaydunkPayment')) {
    class AdminPaydunkPayment
    {
        public function __construct()
        {

        }
    }
}
