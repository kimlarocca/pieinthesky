<div class="paydunk_button_oncart">
    <input class="paydunk-order-button"
           id="paydunk_button_oncart"
           value="Proceed with Paydunk"
           type="button">
	<?php 
		if (isset($add_free_shipping_msg)) 
			{ echo $add_free_shipping_msg;	}
	?>
</div>
