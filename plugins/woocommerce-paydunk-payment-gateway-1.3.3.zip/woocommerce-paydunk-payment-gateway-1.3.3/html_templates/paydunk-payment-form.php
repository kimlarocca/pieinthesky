<form id="pd-paydunkForm0Width">
    <button type="button" id="pd-paydunkButton">Paydunk Payment Button</button>
    <input type="hidden" id="pd-client_id" name="client_id" />
    <input type="hidden" id="pd-order_number" name="order_number" />
    <input type="hidden" id="pd-price" name="price" />
    <input type="hidden" id="pd-tax" name="tax" />
    <input type="hidden" id="pd-shipping" name="shipping" />
</form>
