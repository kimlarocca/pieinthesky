<div class="paydunk-video">
    <iframe width="350" height="200" src="https://www.youtube.com/embed/4ijW-MrFsdg" frameborder="0" allowfullscreen></iframe>
    <p class="paydunk-video-description">
        Paydunk is quite simply the fastest and most secure
        way to buy online. It works with all major credit cards and
        you never have to fill out those checkout forms again.
        <br>Go ahead, try it!
    </p>
</div>